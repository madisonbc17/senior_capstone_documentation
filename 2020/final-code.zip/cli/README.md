# cli
CLI to install and run the express server REST API that ingests and processes the claims
